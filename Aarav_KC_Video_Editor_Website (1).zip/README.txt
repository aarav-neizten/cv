AARAV KC — VIDEO EDITOR PORTFOLIO

HOW TO VIEW
1. Extract the ZIP file.
2. Open index.html in Chrome, Edge, or another browser.

BEFORE PUBLISHING
- Replace YOUR_EMAIL@example.com with your real email.
- Add your phone number / social links if desired.
- Replace the sample project cards with your actual work and portfolio links.
- Update the software list to include only tools you use.
- Check all content for accuracy.

PUBLISHING
You can upload index.html to a static hosting service such as GitHub Pages or Netlify.
This is a static portfolio website; it does not include a backend or contact form submission service.
